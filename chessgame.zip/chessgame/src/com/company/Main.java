package com.company;

import java.util.Locale;
import java.util.Scanner;
import java.util.HashMap;

public class Main
{
    private static Piece[][] board = new Piece[8][8];
    private static HashMap<String, Piece> pieceNames = new HashMap<String, Piece>();
    private static int turn = 1;

    public static Piece pieceCreator(int x, int y, Type t, String n)
    {
        Team team;
        if ((y == 2) || (y == 1))
        {
            team = Team.WHITE;
        } else
        {
            team = Team.BLACK;
        }
        Piece filler = new Piece(x, y, t, team, n);

        board[x - 1][y - 1] = filler;

        return filler;
    }

    public static void hashPut()
    {
        for (int i = 0; i < 8; i++)
        {
            for (int j = 0; j < 8; j++)
            {
                if (board[i][j] != null)
                {
                    pieceNames.put(board[i][j].getName(), board[i][j]);
                }
            }
        }
    }

    public static void boardPrint()
    {
        if (turn%2 == 1)
        {
            for (int j = 7; j >= 0; j--)
            {
                for (int i = 0; i < 8; i++)
                {
                    if (board[i][j] == null)
                    {
                        System.out.print("    ");
                    } else
                    {
                        System.out.print(board[i][j]);
                    }
                }
                System.out.println("\n");
            }
        } else
        {
            for (int j = 0; j < 8; j++)
            {
                for (int i = 0; i < 8; i++)
                {
                    if (board[i][j] == null)
                    {
                        System.out.print("    ");
                    } else
                    {
                        System.out.print(board[i][j]);
                    }
                }
                System.out.println("\n");
            }
        }
    }

    public static boolean isSquareEmpty(int x, int y)
    {
        return (board[x - 1][y - 1] == null);
    }

    public static boolean movement()
    {
        Scanner scan = new Scanner(System.in);
        String team = "";

        if (turn % 2 == 1)
        {
            team = "white";
        } else
        {
            team = "black";
        }

        boolean inside = false;

        System.out.println("Please select your piece, type \"Back\" to choose again, type \"Exit\" to end the program\n");
        System.out.println("Current team is " + team+"\n");
        System.out.println("What piece type do you want; Pawn, Rook, Knight, Bishop, Queen, or King? Type the piece type name to select\n");

        String piece = team.substring(0, 1).toUpperCase();

        String pieceType = scan.nextLine().toLowerCase();
        System.out.println();

        if (pieceType.equals("back"))
            return false;

        if (pieceType.equals("exit"))
            System.exit(69);

        int pieceAmount = 0;

        if ((pieceType.equals("knight")) || (pieceType.equals("rook")) || (pieceType.equals("bishop")))
        {
            pieceAmount = 2;
        } else if (pieceType.equals("pawn"))
        {
            pieceAmount = 8;
        } else if ((pieceType.equals("queen")) || (pieceType.equals("king")))
        {
            pieceAmount = 1;
        } else
        {
            pieceAmount = -1;
        }

        if (pieceAmount == -1)
        {
            return false;
        }

        if (pieceType.equals("knight"))
        {
            pieceType = pieceType.substring(1, 2);
        }

        piece += pieceType.substring(0, 1).toUpperCase();

        if (pieceAmount != 1)
        {
            System.out.println("Which piece number would you like to move? Your options are 1-" + pieceAmount+"\n");

            String pieceNum = scan.nextLine().toLowerCase();
            System.out.println();

            if (pieceNum.equals("back"))
                return false;

            if (pieceNum.equals("exit"))
                System.exit(69);

            piece += pieceNum;
        }

        Piece mover = pieceNames.get(piece);

        System.out.println("Your current position is: "+mover.getX()+","+mover.getY()+"\n");
        System.out.println("What x and y would you like to move to?\n");
        int x = scan.nextInt();
        int y = scan.nextInt();
        scan.nextLine();
        System.out.println();

        if ((x > 8) || (x < 1) || (y > 8) || (y < 1))
        {
            System.out.println("Out of bounds\n");
            return false;
        }

        if (!mover.isAlive())
        {
            return false;
        }

        if (mover.validMove(x, y))
        {
            board[mover.getX() - 1][mover.getY() - 1] = null;
            if (board[x - 1][y - 1] != null && (board[x - 1][y - 1].getTeam() != mover.getTeam()))
            {
                board[x - 1][y - 1].kill();
                board[x - 1][y - 1] = mover;
            } else if (board[x - 1][y - 1] != null)
            {
                return false;
            } else
            {
                board[x - 1][y - 1] = mover;
            }
            mover.setPosition(x, y);
            return true;
        }

        return false;
    }

    public static void main(String[] args)
    {
        // write your code here

        Piece whitePawnOne = pieceCreator(1, 2, Type.PAWN, "WP1");
        Piece whitePawnTwo = pieceCreator(2, 2, Type.PAWN, "WP2");
        Piece whitePawnThree = pieceCreator(3, 2, Type.PAWN, "WP3");
        Piece whitePawnFour = pieceCreator(4, 2, Type.PAWN, "WP4");
        Piece whitePawnFive = pieceCreator(5, 2, Type.PAWN, "WP5");
        Piece whitePawnSix = pieceCreator(6, 2, Type.PAWN, "WP6");
        Piece whitePawnSeven = pieceCreator(7, 2, Type.PAWN, "WP7");
        Piece whitePawnEight = pieceCreator(8, 2, Type.PAWN, "WP8");
        Piece whiteRookOne = pieceCreator(1, 1, Type.ROOK, "WR1");
        Piece whiteRookTwo = pieceCreator(8, 1, Type.ROOK, "W2");
        Piece whiteKnightOne = pieceCreator(2, 1, Type.KNIGHT, "WN1");
        Piece whiteKnightTwo = pieceCreator(7, 1, Type.KNIGHT, "WN2");
        Piece whiteBishopOne = pieceCreator(3, 1, Type.BISHOP, "WB1");
        Piece whiteBishopTwo = pieceCreator(6, 1, Type.BISHOP, "WB2");
        Piece whiteQueen = pieceCreator(4, 1, Type.QUEEN, "WQ");
        Piece whiteKing = pieceCreator(5, 1, Type.KING, "WK");

        Piece blackPawnOne = pieceCreator(1, 7, Type.PAWN, "BP1");
        Piece blackPawnTwo = pieceCreator(2, 7, Type.PAWN, "BP2");
        Piece blackPawnThree = pieceCreator(3, 7, Type.PAWN, "BP3");
        Piece blackPawnFour = pieceCreator(4, 7, Type.PAWN, "BP4");
        Piece blackPawnFive = pieceCreator(5, 7, Type.PAWN, "BP5");
        Piece blackPawnSix = pieceCreator(6, 7, Type.PAWN, "BP6");
        Piece blackPawnSeven = pieceCreator(7, 7, Type.PAWN, "BP7");
        Piece blackPawnEight = pieceCreator(8, 7, Type.PAWN, "BP8");
        Piece blackRookOne = pieceCreator(1, 8, Type.ROOK, "BR1");
        Piece blackRookTwo = pieceCreator(8, 8, Type.ROOK, "BR2");
        Piece blackKnightOne = pieceCreator(2, 8, Type.KNIGHT, "BN1");
        Piece blackKnightTwo = pieceCreator(7, 8, Type.KNIGHT, "B");
        Piece blackBishopOne = pieceCreator(3, 8, Type.BISHOP, "BB1");
        Piece blackBishopTwo = pieceCreator(6, 8, Type.BISHOP, "BB2");
        Piece blackQueen = pieceCreator(4, 8, Type.QUEEN, "BQ");
        Piece blackKing = pieceCreator(5, 8, Type.KING, "BK");

        hashPut();

        while (turn > 0)
        {
            boardPrint();

            boolean finishedMove = false;

            while (!finishedMove)
            {
                finishedMove = movement();
                if (!finishedMove)
                {
                    System.out.println("Invalid move!");
                }
            }

            turn++;
        }


    }
}

