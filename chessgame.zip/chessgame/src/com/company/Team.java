package com.company;

public enum Team
{
    WHITE, BLACK
}