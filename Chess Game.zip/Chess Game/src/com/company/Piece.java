package com.company;

import java.lang.Math;

public class Piece
{
    private int[] position = new int[2];
    private Type pieceType;
    private boolean alive;
    private Team team;
    private String name;

    public Piece(int x, int y, Type t, Team b, String n)
    {
        position[0] = x;
        position[1] = y;
        pieceType = t;
        alive = true;
        team = b;
        name = n;
    }

    public String toString()
    {
        if (pieceType == Type.KNIGHT)
            return " " + team.name().charAt(0) + "N ";

        return " " + team.name().charAt(0) + pieceType.name().charAt(0) + " ";
    }

    public boolean validMove(int x, int y)
    {
        int xDiff = x - position[0];
        int yDiff = y - position[1];
        switch (pieceType)
        {
            case PAWN:
                if (team == Team.WHITE)
                {
                    if (position[1] == 2)
                    {
                        if ((yDiff == 2) && (xDiff == 0))
                        {
                            return (Main.isSquareEmpty(x, position[1] + 1) && Main.isSquareEmpty(x, position[1] + 2));
                        } else if ((yDiff == 1) && (xDiff == 0))
                        {
                            return Main.isSquareEmpty(x, position[1] + 1);
                        }
                    } else
                    {
                        if ((yDiff == 1) && (xDiff == 0))
                        {
                            return Main.isSquareEmpty(x, position[1] + 1);
                        }
                    }
                } else
                {
                    if (position[1] == 7)
                    {
                        if ((yDiff == -2) && (xDiff == 0))
                        {
                            return (Main.isSquareEmpty(x, position[1] - 1) && Main.isSquareEmpty(x, position[1] - 2));
                        } else if ((yDiff == 1) && (xDiff == 0))
                        {
                            return Main.isSquareEmpty(x, position[1] - 1);
                        }
                    } else
                    {
                        if ((yDiff == -1) && (xDiff == 0))
                        {
                            return Main.isSquareEmpty(x, position[1] - 1);
                        }
                    }
                }
                break;
            case ROOK:
                if ((xDiff == 0) && (yDiff != 0))
                {
                    boolean empty = true;

                    if (yDiff > 0)
                    {
                        for (int i = y - 1; i > position[1]; i--)
                        {
                            if (!Main.isSquareEmpty(x, i))
                            {
                                empty = false;
                            }
                        }
                    } else
                    {
                        for (int i = y + 1; i < position[1]; i++)
                        {
                            if (!Main.isSquareEmpty(x, i))
                            {
                                empty = false;
                            }
                        }
                    }

                    return empty;
                } else if ((xDiff != 0) && (yDiff == 0))
                {
                    boolean empty = true;

                    if (xDiff > 0)
                    {
                        for (int i = x - 1; i > position[0]; i--)
                        {
                            if (!Main.isSquareEmpty(i, y))
                            {
                                empty = false;
                            }
                        }
                    }
                    return empty;
                }
                break;
            case KNIGHT:
                if (((Math.abs(xDiff) == 2) && (Math.abs(yDiff) == 1)) || ((Math.abs(xDiff) == 1) && (Math.abs(yDiff) == 2)))
                {
                    return (Main.isSquareEmpty(x, y));
                }
                break;
            case BISHOP:
                if ((Math.abs(xDiff) == Math.abs(yDiff)))
                {
                    boolean up = (yDiff > 0);
                    boolean right = (xDiff > 0);

                    boolean empty = true;

                    if (up && right)
                    {
                        for (int i = 0; i < Math.abs(xDiff); i++)
                        {
                            if (!Main.isSquareEmpty(position[0] + i, position[1] + i))
                            {
                                empty = false;
                            }
                        }
                    } else if (!up && right)
                    {
                        for (int i = 0; i < Math.abs(xDiff); i++)
                        {
                            if (!Main.isSquareEmpty(position[0] + i, position[1] - i))
                            {
                                empty = false;
                            }
                        }
                    } else if (up && !right)
                    {
                        for (int i = 0; i < Math.abs(xDiff); i++)
                        {
                            if (!Main.isSquareEmpty(position[0] - i, position[1] + i))
                            {
                                empty = false;
                            }
                        }
                    } else if (!up && !right)
                    {
                        for (int i = 0; i < Math.abs(xDiff); i++)
                        {
                            if (!Main.isSquareEmpty(position[0] - i, position[1] - i))
                            {
                                empty = false;
                            }
                        }
                    }

                    return empty;
                }
                break;
            case QUEEN:
                if ((xDiff == 0) && (yDiff != 0))
                {
                    boolean empty = true;

                    if (yDiff > 0)
                    {
                        for (int i = y - 1; i > position[1]; i--)
                        {
                            if (!Main.isSquareEmpty(x, i))
                            {
                                empty = false;
                            }
                        }
                    } else
                    {
                        for (int i = y + 1; i < position[1]; i++)
                        {
                            if (!Main.isSquareEmpty(x, i))
                            {
                                empty = false;
                            }
                        }
                    }

                    return empty;
                } else if ((xDiff != 0) && (yDiff == 0))
                {
                    boolean empty = true;

                    if (xDiff > 0)
                    {
                        for (int i = x - 1; i > position[0]; i--)
                        {
                            if (!Main.isSquareEmpty(i, y))
                            {
                                empty = false;
                            }
                        }
                    }
                } else if ((Math.abs(xDiff) == Math.abs(yDiff)))
                {
                    boolean up = (yDiff > 0);
                    boolean right = (xDiff > 0);

                    boolean empty = true;

                    if (up && right)
                    {
                        for (int i = 0; i < Math.abs(xDiff); i++)
                        {
                            if (!Main.isSquareEmpty(position[0] + i, position[1] + i))
                            {
                                empty = false;
                            }
                        }
                    } else if (!up && right)
                    {
                        for (int i = 0; i < Math.abs(xDiff); i++)
                        {
                            if (!Main.isSquareEmpty(position[0] + i, position[1] - i))
                            {
                                empty = false;
                            }
                        }
                    } else if (up && !right)
                    {
                        for (int i = 0; i < Math.abs(xDiff); i++)
                        {
                            if (!Main.isSquareEmpty(position[0] - i, position[1] + i))
                            {
                                empty = false;
                            }
                        }
                    } else if (!up && !right)
                    {
                        for (int i = 0; i < Math.abs(xDiff); i++)
                        {
                            if (!Main.isSquareEmpty(position[0] - i, position[1] - i))
                            {
                                empty = false;
                            }
                        }
                    }

                    return empty;
                }
            case KING:
                if (((Math.abs(xDiff) == 0) && (Math.abs(yDiff) == 1)) || ((Math.abs(xDiff) == 1) && (Math.abs(yDiff) == 0)) || ((Math.abs(xDiff) == 1) && (Math.abs(yDiff) == 1)))
                {
                    return Main.isSquareEmpty(x,y);
                }
        }
        return false;
    }

    public String getName()
    {
        return name;
    }

    public int getX()
    {
        return position[0];
    }

    public int getY()
    {
        return position[1];
    }

    public void setPosition(int x, int y)
    {
        position[0] = x;
        position[1] = y;
    }

    public boolean isAlive()
    {
        return alive;
    }

    public void kill()
    {
        alive = false;
    }

    public Team getTeam()
    {
        return team;
    }
}
